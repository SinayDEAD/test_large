package de.mariushoefler.flutterenhancementsuite.editor.icons

import de.mariushoefler.flutterenhancementsuite.editor.FlutterIcons

object FontAwesomeIcons : FlutterIcons<FontAwesomeIcons>("font_awesome", FontAwesomeIcons::class.java)
