package de.mariushoefler.flutterenhancementsuite.editor.icons

import de.mariushoefler.flutterenhancementsuite.editor.FlutterIcons

object IonIcons : FlutterIcons<IonIcons>("ion", IonIcons::class.java)
