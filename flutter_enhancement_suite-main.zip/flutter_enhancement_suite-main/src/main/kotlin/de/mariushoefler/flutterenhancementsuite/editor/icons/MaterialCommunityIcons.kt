package de.mariushoefler.flutterenhancementsuite.editor.icons

import de.mariushoefler.flutterenhancementsuite.editor.FlutterIcons

object MaterialCommunityIcons :
    FlutterIcons<MaterialCommunityIcons>("material_community", MaterialCommunityIcons::class.java)
