package de.mariushoefler.flutterenhancementsuite.models

data class VersionDescription(
    val counter: Int,
    val currentVersion: String,
    val latestVersion: String
)
