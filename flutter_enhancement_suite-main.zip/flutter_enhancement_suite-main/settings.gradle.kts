rootProject.name = "flutterenhancementsuite"
