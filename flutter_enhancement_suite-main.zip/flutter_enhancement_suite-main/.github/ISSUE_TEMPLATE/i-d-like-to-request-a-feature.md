---
name: I'd like to request a feature
about: Suggest a new idea for this plugin.
title: ''
labels: enhancement
assignees: ''

---

**Describe the use-cases of your feature**

<!--A clear and concise description of when you would need that feature.-->

**Describe your solution**

<!--A clear and concise description of what you want to happen. You can also use images in order to show how you want your feature to be implemented.-->
