using System.Reflection;

[assembly: AssemblyVersion("0.0.0.0")] 
[assembly: AssemblyFileVersion("0.0.0.0")] 
[assembly: AssemblyInformationalVersion("0.0.0.0 Development")] 
[assembly: AssemblyConfiguration("Development")]

