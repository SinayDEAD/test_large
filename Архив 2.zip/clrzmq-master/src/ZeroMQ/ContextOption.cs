﻿namespace ZeroMQ
{
    internal enum ContextOption
    {
        IO_THREADS = 1,
        MAX_SOCKETS = 2
    }
}
