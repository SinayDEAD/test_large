# COBOL - Apps
Apps created to learn about programming in COBOL...

## INDEX:
- [Convert Roman to Decimal](https://github.com/raphaelfrei/cobol-apps/tree/main/Basic%20Roman%20to%20Decimal)
- [CPF Digit Verification](https://github.com/raphaelfrei/cobol-apps/tree/main/CPF%20-%20Digits%20Verification)
- [Basic CSV Writer](https://github.com/raphaelfrei/cobol-apps/tree/main/CSV%20Writer)
- [M365 Admin Center - CSV Writer](https://github.com/raphaelfrei/cobol-apps/tree/main/M365%20-%20Admin%20Center%20CSV%20Writer)
- [Contact List Writer in DAT](https://github.com/raphaelfrei/cobol-apps/tree/main/Contact%20List%20Writer)
- [Decimal is Comma](https://github.com/raphaelfrei/cobol-apps/tree/main/Dec%20Is%20Comma)
- [Student Grade Average](https://github.com/raphaelfrei/cobol-apps/tree/main/Student%20Grade%20Average)
- [Basic Training Apps](https://github.com/raphaelfrei/cobol-apps/tree/main/Training%20Apps)
