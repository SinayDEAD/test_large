# COBOL - User Maintenance (Contact List)
Simple user management with COBOL.


Operations includes: Create, Search, List, Delete and Change registers

All the informations are saved in a .DAT File
