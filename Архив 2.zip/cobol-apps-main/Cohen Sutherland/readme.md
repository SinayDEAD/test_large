# Cohen Sutherland in COBOL
<p>Created for a college activity.</p>
