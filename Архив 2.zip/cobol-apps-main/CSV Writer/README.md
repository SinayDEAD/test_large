# COBOL - CSV Writer
Simple COBOL CSV Writer for YouTube Video...
[Watch Here](https://youtu.be/IjWHM1pwW_I)

### It writes the following data:

X(10) - First Name<br>
X(10) - Last Name<br>
X(30) - Email<br>
9(13) - Phone Number (BR Format)
