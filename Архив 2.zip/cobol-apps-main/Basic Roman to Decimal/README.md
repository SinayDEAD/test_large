# COBOL - Roman to Decimal
Convert Roman Numbers to Decimal
<br><br>
This app only includes a basic direct-conversion from letters to number. <br>
**Not included yet:** Rules like IX = 9 *(IX will be 11)*
