# COBOL - Apps
Creating programs to understand the basics about COBOL
