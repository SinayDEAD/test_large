# COBOL - Decimal Point is Comma
Set comma as decimal point in COBOL<br>
Just copy the code inside the Enviroment Division
