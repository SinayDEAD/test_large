**Que sistema operativo usas ? // What operating system and version?**

**Que hiciste para que ocurriera? // What did you do?**

**Que esperabas que pase? // What did you expect to happen?**

**Que fue lo que paso? // What actually happened?**
