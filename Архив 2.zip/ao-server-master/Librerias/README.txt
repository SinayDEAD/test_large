Pueden utilizar el programa AdminLibSetup para registrar las librerias o pueden simplemente copiarlas
y pegarlas en la carpeta C:\Windows\
