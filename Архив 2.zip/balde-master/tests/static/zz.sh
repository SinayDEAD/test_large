#!/bin/bash

zz() {
    :
}
