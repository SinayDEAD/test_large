function a() {
    alert('lol');
}
