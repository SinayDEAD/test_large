/*
 * balde: A microframework for C based on GLib.
 * Copyright (C) 2013-2017 Rafael G. Martins <rafael@rafaelmartins.eng.br>
 *
 * This program can be distributed under the terms of the LGPL-2 License.
 * See the file COPYING.
 */

#ifndef _BALDE_PRIVATE_H
#define _BALDE_PRIVATE_H

#define BALDE_API __attribute__((visibility("default")))

#endif /* _BALDE_PRIVATE_H */
