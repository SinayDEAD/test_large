#!/bin/bash

autoreconf \
    --warnings=all \
    --install \
    --force
