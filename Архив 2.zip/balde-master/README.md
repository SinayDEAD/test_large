balde
=====

[![Build Status](https://travis-ci.org/balde/balde.svg?branch=master)](https://travis-ci.org/balde/balde)

This is *balde*, a microframework for C based on GLib.

It is designed to be fast, simple, and memory efficient. Most of its architecture is based on other microframeworks, like Flask, and it can run on any web server that supports CGI and/or FastCGI.

*balde* is free software, released under the LGPL2 license.

For more information, take a look at:

- https://balde.rgm.io/
