Application Structure {#application-structure}
=====================

TODO
