API changes {#api-changes}
===========

This page documents API changes that breaks applications developed with balde. Please fix your code!


Since 0.2
---------

TODO: write me!
