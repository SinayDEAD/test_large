balde artwork
=============

This directory stores balde logo. It was fetched from http://openclipart.org/detail/174088/bucket-by-mirek2-174088 and is released under [Public Domain](http://creativecommons.org/publicdomain/zero/1.0/).
