package aia.stream

case class Summary(events: Vector[Event])