# encoding: utf-8
# ******************************************************
# Author       : zzw922cn
# Last modified: 2017-12-09 11:00
# Email        : zzw922cn@gmail.com
# Filename     : __init__.py
# Description  : Libraries for n-gram model
# ******************************************************

from speechvalley.models.ngram.generate import *
from speechvalley.models.ngram.ngram import *
