# encoding: utf-8
# ******************************************************
# Author       : zzw922cn
# Last modified: 2017-12-09 11:00
# Email        : zzw922cn@gmail.com
# Filename     : __init__.py
# Description  : Feature preprocessing for TIMIT dataset
# ******************************************************

from speechvalley.feature.timit.timit_preprocess import wav2feature
