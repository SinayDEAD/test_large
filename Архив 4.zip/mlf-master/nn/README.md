需要实现的模型：Artificial Neural Network

预计模型实现的时间：2014 Q2/3
