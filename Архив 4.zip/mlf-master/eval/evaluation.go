package eval

type Evaluation struct {
	Metrics map[string]float64
}
