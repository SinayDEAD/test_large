如果你想使用这个框架，除了需要遵守Apache License v2外没有任何限制，欢迎商业应用。

如果你想了解开发规划或者和我讨论这个项目，请加入[邮件列表](https://groups.google.com/forum/#!forum/mlf-users)。

如果你想回馈代码，应该在发送一个pull request前和我充分讨论你的点子，这帮助我读懂你的修改并尽可能快地完成代码审查。

如果你想捐赠，我的淘宝/paypal/wallet账号是 unmerged 艾特 那个谷歌信箱。
