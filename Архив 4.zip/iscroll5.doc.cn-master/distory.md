##销毁
<h2 id="destroy">Destroy</h2>

在不需要使用iScoll的时候调用iScroll实例的公共方法`destroy()`可以释放一些内存。
```js
myScroll.destroy();
myScroll = null;
```
