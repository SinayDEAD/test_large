```Call import by update status field``` is a example for start an import over trigger and dataqueues 

```COPY_SPOOLEDFILE_TO_PDF``` is a SQL-UDF to copy spooled files to PDF-files within the IFS.
It return 0 for success and -1 for failure
Example:
```
VALUES(BRUNNER.COPY_SPOOLEDFILE_TO_PDF(         
       'QPRTLIBL',
       '818377/USER/SESSIONA', 
       1,
       '/tmp/QPRTLIBL_test.pdf'))
```

```EXECUTECOMMAND``` executes system commands.

Example:
```
SELECT executeCommand ('SNDMSG MSG(''' CONCAT TRIM(text_description) CONCAT ''') TOUSR(USER)')                                
 FROM QSYS2.USER_INFO
WHERE text_description LIKE '%Brunner%' LIMIT 10;
```

```LISTSAMPLE``` shows how to use commands with parms (list-parms).

```SETFREE``` shows how to manipulate the source-code to add colors (if, endif etc).

```RLSNSURG``` shows how to reenable disabled userprofiles for the NETSERVER shares.

```FileDef_Proc``` shows how to declare a file within an procedure.

```DSPUIMWDW``` shows how to use API QUILNGTX for a easy window.

```CLCEAP``` is an example how to calculate a checkdigit with mod10

```CRYPT, CRYPTIFSCL```: encrypt or decrypt streamfiles via openssl and tdes
                   encode and decode streamfiles to/from base64 via openssl

```AUFAN2RG, AUFAN2DF``` shows how to make a autorefreshing subfileprogram with DTAQ (example).

```ZTLSCLRG``` is a example for a tls/ssl client application using the socket/gsk-api's from scott klement

```GETWEBF/GETWEBFRG``` uses the UDF HTTPGETBLOB to download a file from the web onto your ifs 
   (example: ```GETWEBF URL('http://www.liferadio.tirol/webcam/Studio1.jpg') PATH('/tmp/Studio.jpg')``` )
   CAUTION! The UDF HTTPGETBLOB starts a JVM for each calling job!

```HTML_CLOB``` imports a html-template in a clob-var, replace the vars and write it via clob_file to a new one

```TESTXLSX``` is a sample to show how to use the libxlsx to create directly excel-sheets from rpg

```NOLOGIN``` shows how to override an interactive job to an prestarted batch-job. In this case no login is neccessary to run the program called in the CL

```"Asyncronous interactive job example"``` contains an example to call an interactive job without login and control it via dataqueue.
For this example i have created an own subsystem / signon / user with specific ws entries. 
The user from the signon have to set the proto2rg as startprogram. 
The dataqueues must be defined variable on a live system. The logic to find the correct dataqueue is currently missing.
