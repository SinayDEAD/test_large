require 'test/unit'
exit Test::Unit::AutoRunner.run(true, File.dirname($0))
