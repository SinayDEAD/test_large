class HTTPClient
  VERSION = '2.8.3'
end
