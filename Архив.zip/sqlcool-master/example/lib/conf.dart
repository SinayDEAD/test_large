import 'package:sqlcool/sqlcool.dart';

final SqlDb db = SqlDb();
final Db db2 = Db();
