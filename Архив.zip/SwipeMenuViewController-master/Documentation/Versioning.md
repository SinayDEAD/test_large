## Versioning
### ~ 1.1.5
- Xcode 8.x
- Swift 3.x

### 1.2.0
- Xcode 9.x
- Swift 3.2

### 2.0.0 ~
- Xcode 9.x
- Swift 4.0, 4.1

### 3.0.0 ~
- Xcode 10.x
- Swift 4.2 ~

### 4.0.0 ~
- Xcode 11.x
- Swift5.0 ~
