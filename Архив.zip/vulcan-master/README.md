
Status
------

This library has been refactored into: https://github.com/mailgun/oxy and is being deprecated


[OXY](https://github.com/mailgun/oxy) is compatible with HTTP standard library, provides the same features as Vulcan and is simpler to use. Please consider using it instead.

Vulcan library will stay there for a while in case if you are using it, but I would suggest consider migrating. Vulcand project is currently migrating to oxy library.

